import math

a=5
b=6
result = 5 == 6
print(result)
print(a != b)
print(a > b)
print(a < b)
bool1=True
bool1=False
print(bool1 ++bool2)
age=22
weight=58
result=age>21 and weight == 58
print(result)
age = 22
isMarried = False
result = age > 21 or isMarried
print(result)
age = 22
isMarried = False
print(not age >21)
print(not isMarried)
print(not 4)
print(not 0)
message = "hello world!"
hello = "hello"
print(hello in message)
gold = "gold"
print (gold in message)
language= "english"
if language == "english":
    print("Hello")
print("End")
language="english"
if language == "english":
    print("Hello")
    prin("End")
language = "russian"
if language == "english":
    print("Hello")
else:
    print("Привет")
print("End")
language= "german"
if language == "english":
    print ("Hello:")
    print ("World")
z=input()
if z>=0
elif z>=0
    print(2*z+1)
elif z<0
    print(math.log(z**2-z))
print y= (math.sin(z) **2*x+math.cos(z)**5*x**3+math.log(x**2/5))
