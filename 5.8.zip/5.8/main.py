import random
print("Поиграем. Я загадал число от 1 до 100. Попробуй угадай.")
print("Я буду давать подсказки")
random_number = random.randint(1, 100)
user_number= int(input("Ваше предположение: "))
pop = 10
while user_number != random_number:
    if user_number > random_number:
        print("Меньше...")
    else:
        print("Больше...")
    if pop == 0:
        break
    user_number= int(input("Ваше предположение: "))
    pop -= 1
if user_number != random_number:
    print("Ты истратил все попытки")
    print({random_number})
else:
    print("Молодец!")