import
to_list(a,g,f,w)
reversed a
change(lst)
to_list()
useless(s)
list_sort(lst)
all_eq(lst)