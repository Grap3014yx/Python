import math
import random
while ("0 + - * /")
a= input("Первое число")
b= input("Второе число")
operation= input("Операция")
print(a+operation+b)

a=input()
print()



a=input("Число для факториала")
print(math.factorial(a))

import random
Computer_number=(random)
You_number=(input("Число для отгадывания"))
 if You_number=Computer_number
     else:
        print("You win")
 if You_number not Computer_number
    else:
        print("You lose")









