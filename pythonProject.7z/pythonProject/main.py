import math

isGood = True
print()
isAlive = False
print(isAlive)

print("")

a1 = 0x77
a2 = 0b1011
a3 = 0o77
print(a1)
print(a2)
print(a3)
text = '''Hello, my name Alex
my age - 22
my height - 999
'''
print(text)

print("__________________________")
Name1 = input()
Name2 = input()
print('Ваше имя - ', Name1)
print('Ваша фамилия - ', Name2)
print("__________________________")


#Индивидуальное задание
print("")
print("Введите чему равно угол alfa:")
a = int(input())
print("Введите чему равно угол beta:")
b = int(input())
z1 = (math.cos(a) - math.sin(b))**2-(math.sin(a)-math.sin(b))**2
print(z1)
z2 = -4 * math.sin((a-b)/2)**2 * math.cos(a+b)
print(z2)

