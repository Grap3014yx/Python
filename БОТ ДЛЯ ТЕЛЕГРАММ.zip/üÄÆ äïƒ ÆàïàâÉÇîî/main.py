import telebot
from telebot import types
token=("6192911819:AAEF8Y5ea9SqFUQ0fEd0YvVhnA7b72gTAFA")
bot=telebot.TeleBot('6192911819:AAEF8Y5ea9SqFUQ0fEd0YvVhnA7b72gTAFA')
@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id,'Привет, готов наполнить список мангой и аниме?')
    @bot.message_handler(commands=['button'])
    def button_message(message):
        markup=types.ReplyKeyboardMarkup(resize_keyboard=true)
        item1=types.KeyboardButton("Мое аниме")
        markup.add(item1)
        bot.send_message(message.chat.id, "Выберите что вам надо", reply_markup=markup)
bot.infinity_polling()
